import discord
from discord.ext import commands
from discord import app_commands

TOKEN = 'MTIwNzMwMjY0ODgwMjQ1MTQ3Ng.GYvn3y.asB9cyoKhG5VNhEiHiFKKLTC8Xv5njJ-_N457k'  # Substitua pelo seu token
ROLE_ID = 1279903295326126090
CODES = {'Lq8*V9b&N5', 'Xz!4T3r@M1', 'A7g#J2!kD9'}
CHANNEL_ID = 1281326837586198528  # ID do canal onde o comando pode ser usado

intents = discord.Intents.default()

bot = commands.Bot(command_prefix='!', intents=intents)

used_codes = set()

@bot.event
async def on_ready():
    print(f'Bot está online como {bot.user.name}')
    try:
        await bot.tree.sync()
        print('Comandos de slash sincronizados com o Discord.')
    except Exception as e:
        print(f'Erro ao sincronizar comandos: {e}')

@bot.tree.command(name="resgate", description="Resgate um código para receber um cargo.")
@app_commands.describe(codigo="Digite o código de resgate.")
async def resgate(interaction: discord.Interaction, codigo: str):
    if interaction.channel.id != CHANNEL_ID:
        await interaction.response.send_message('Este comando não pode ser usado neste canal.', ephemeral=True)
        return

    codigo = codigo.strip()

    if codigo in CODES:
        if codigo not in used_codes:
            used_codes.add(codigo)
            role = interaction.guild.get_role(ROLE_ID)
            if role:
                try:
                    await interaction.user.add_roles(role)
                    await interaction.response.send_message('Código válido! O cargo foi atribuído a você.', ephemeral=True)
                except discord.Forbidden:
                    await interaction.response.send_message('Não tenho permissão para adicionar o cargo.', ephemeral=True)
                except discord.HTTPException:
                    await interaction.response.send_message('Ocorreu um erro ao adicionar o cargo.', ephemeral=True)
            else:
                await interaction.response.send_message('Cargo não encontrado.', ephemeral=True)
        else:
            await interaction.response.send_message('Código já utilizado.', ephemeral=True)
    else:
        await interaction.response.send_message('Código inválido.', ephemeral=True)

bot.run(TOKEN)
